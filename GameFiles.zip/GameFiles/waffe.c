// In "waffe.c"
#include "waffe.h"

struct Waffe waffe1 = {
    "Schwert",
    300,
    5,
    };

struct Waffe waffe2 = {
    "Bogen",
    30,
    50,
    };

struct Waffe waffe1, waffe2;
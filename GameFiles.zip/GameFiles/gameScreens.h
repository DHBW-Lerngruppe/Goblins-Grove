int menu();
int gameover();
int endGame();
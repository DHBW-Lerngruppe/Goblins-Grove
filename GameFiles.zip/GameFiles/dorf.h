#ifndef DORF_H
#define DORF_H

int dorf();

#endif /* DORF_H */
